var express = require('express')();
//var router = express.Router();

var server = require('http').Server(express);
var io = require('socket.io')(server);

server.listen(3080);

/* GET home page. */
express.get('/', function(req, res, next) {
	
	
	/*kafka implementation*/
	
	
  res.render('index', { title: 'kafka Demo' });
});

io.on('connection', function (socket) {
	
	var kafka = require('kafka-node');
	var Consumer = kafka.Consumer;
    var client = new kafka.KafkaClient({kafkaHost:'133.0.109.205:9092,133.0.109.206:9092,133.0.109.207:9092'});
	//var client = new kafka.KafkaClient({KafkaHost:'localhost:9092,localhost2:9092'}); //测试
    var Offset = kafka.Offset;
    var offset = new Offset(client);
    console.log('连接kafka中--topic');
    var topics = [{
        topic: 'Topic_use_cs', partition: 0
    }];
	console.log('连接kafka中--options');
    var options = {
		groupId: 'gxmgz3'
    };
	console.log('连接kafka中--开始连接');
    var consumer = new Consumer(
        client,
        topics,
        options
    );
	
	console.log('连接kafka中--消息输出');
		consumer.on('message', function (message) {
			console.log('获取消息');
			socket.emit('news', { msg: message.value });
		});
		console.log('kafka消息接受结束');
		consumer.on('offsetOutOfRange', function (topic) {
		   console.log("------------- offsetOutOfRange ------------");
		   topic.maxNum = 2;
		   offset.fetch([topic], function (err, offsets) {
			   console.log(offsets);
			   var min = Math.min.apply(null, offsets[topic.topic][topic.partition]);
			   consumer.setOffset(topic.topic, topic.partition, min);
		   });
		});
		consumer.on('error', function (message) {
			console.log(message.value);
			console.log('kafka错误');
			return
		});
});

module.exports = express;
