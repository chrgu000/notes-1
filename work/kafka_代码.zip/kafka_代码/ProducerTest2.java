package test.com;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;

import kafka.producer.ProducerConfig;

public class ProducerTest2 {

	public static void main(String[] args) throws Exception {

		
		Properties props = new Properties();
		props.setProperty("metadata.broker.list", "192.168.174.12:9092,192.168.174.13:9092,192.168.174.14:9092");
		props.put("bootstrap.servers", "192.168.174.12:9092,192.168.174.13:9092,192.168.174.14:9092");

		props.setProperty("serializer.class", "kafka.serializer.StringEncoder");
		props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		props.put("request.required.acks", "1");
		
		props.put("replication.factor", "1");
		
		props.put("partitioner.class", "com.bonc.SimplePartitioner");
		
		KafkaProducer<String, String> producer = new KafkaProducer<String, String>(props);
		// KeyedMessage<String, String> data = new KeyedMessage<String,
		// String>("WordCount", "test-kafka");
		
	
		while (true) {
			BufferedReader br = new BufferedReader(new FileReader(new File(
					"C:\\Users\\daijinbao\\Desktop\\idea\\2017081111350778990059058.txt\\2017081111350778990059058.txt")));
			// producer.send(new KeyedMessage<String, String>("WordCount2",
			// "daijinbao"));
			String line = null;
			int i = 0;

			long start = System.currentTimeMillis();
			while ((line = br.readLine()) != null) {
		
				i++;
				i = i % 9;
			//	System.out.println(	"this is nums "+SimplePartitioner2.size_temp);
				producer.send(new ProducerRecord<String, String>("Topic_gn_url", i + "", line));// 
				// System.out.println(line); // 
				// System.out.println(i % 30);

			}
			long end = System.currentTimeMillis();
			System.out.println((end - start) / 1000);
			/*
			 * int i=0; while(i<100){ producer.send(new KeyedMessage<String,
			 * String>("WordCount6", "Sdafds zhanglong2")); }
			 */

			// System.out.println("daijinbao");

			// producer.close();

		}

	}

}
